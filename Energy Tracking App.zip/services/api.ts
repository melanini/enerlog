// API service placeholder - Supabase integration temporarily disabled
export const apiService = {};